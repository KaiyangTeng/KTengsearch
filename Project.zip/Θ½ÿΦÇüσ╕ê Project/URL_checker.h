#include <string>
using namespace std;

class URL_checker
{
public:
    bool is_valid(const string& url);
};
